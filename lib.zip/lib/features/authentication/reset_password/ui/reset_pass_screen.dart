import 'package:flutter/material.dart';

import 'widgets/reset_pass_body.dart';

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: ResetPassBody());
  }
}
