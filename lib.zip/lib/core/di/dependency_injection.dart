import 'package:get_it/get_it.dart';
import 'package:vernita/core/helper/shared_pref_helper.dart';
import 'package:vernita/core/network/api_service.dart';
import 'package:vernita/core/network/dio_factory.dart';
import 'package:vernita/core/storage/auth_token_storage.dart';
import 'package:vernita/features/authentication/forget_password/data/repo/forget_pass_repo.dart';
import 'package:vernita/features/authentication/forget_password/data/repo/forget_pass_repo_imp.dart';
import 'package:vernita/features/authentication/forget_password/logic/forget_pass_cubit.dart';
import 'package:vernita/features/authentication/logic/auth_session_cubit.dart';
import 'package:vernita/features/authentication/log_in/data/repo/log_in_repo.dart';
import 'package:vernita/features/authentication/log_in/data/repo/log_in_repo_imp.dart';
import 'package:vernita/features/authentication/log_in/logic/log_in_cubit.dart';
import 'package:vernita/features/authentication/reset_password/data/repo/reset_pass_repo.dart';
import 'package:vernita/features/authentication/reset_password/data/repo/reset_pass_repo_imp.dart';
import 'package:vernita/features/authentication/reset_password/logic/reset_pass_cubit.dart';
import 'package:vernita/features/authentication/sign_up/data/repo/sign_up_repo.dart';
import 'package:vernita/features/authentication/sign_up/data/repo/sign_up_repo_imp.dart';
import 'package:vernita/features/authentication/sign_up/logic/sign_up_cubit.dart';
import 'package:vernita/features/calendar/logic/calendar_cubit.dart';
import 'package:vernita/features/home/data/data_source/cv_remote_data_source.dart';
import 'package:vernita/features/home/data/repo/cv_repo.dart';
import 'package:vernita/features/home/data/repo/cv_repo_imp.dart';
import 'package:vernita/features/home/logic/cv_upload_cubit.dart';
import 'package:vernita/features/profile/profile/data/repo/profile_repo.dart';
import 'package:vernita/features/profile/profile/data/repo/profile_repo_imp.dart';
import 'package:vernita/features/profile/profile/logic/profile_cubit.dart';

final getIt = GetIt.instance;

Future<void> getItSetup() async {
  await SharedPrefHelper.init();

  getIt.registerLazySingleton<CalendarCubit>(() => CalendarCubit());

  // The token storage must exist first: Dio uses it to add the token.
  getIt.registerLazySingleton<AuthTokenStorage>(() => AuthTokenStorage());
  getIt.registerLazySingleton<AuthSessionCubit>(
    () => AuthSessionCubit(getIt()),
    dispose: (cubit) => cubit.close(),
  );

  final dio = DioFactory.getDio(
    readToken: () => getIt<AuthTokenStorage>().readToken(),
    onUnauthorized: () => getIt<AuthSessionCubit>().invalidateSession(),
  );
  await DioFactory.addDioHeaders();
  getIt.registerLazySingleton<ApiService>(() => ApiService(dio));

  getIt.registerLazySingleton<CvRemoteDataSource>(
    () => CvRemoteDataSource(dio),
  );
  getIt.registerLazySingleton<CvRepo>(() => CvRepoImp(getIt()));
  getIt.registerFactory<CvUploadCubit>(() => CvUploadCubit(getIt()));

  getIt.registerLazySingleton<SignUpRepo>(() => SignUpRepoImp(getIt()));
  getIt.registerFactory<SignUpCubit>(
  () => SignUpCubit(getIt(), getIt<LogInRepo>(), getIt<AuthSessionCubit>()),
);

  getIt.registerLazySingleton<LogInRepo>(() => LogInRepoImp(getIt()));
  getIt.registerFactory<LogInCubit>(
    () => LogInCubit(getIt(), getIt<AuthSessionCubit>()),
  );

  getIt.registerLazySingleton<ForgetPassRepo>(() => ForgetPassRepoImp(getIt()));
  getIt.registerFactory<ForgetPassCubit>(() => ForgetPassCubit(getIt()));

  getIt.registerLazySingleton<ResetPassRepo>(() => ResetPassRepoImp(getIt()));
  getIt.registerFactory<ResetPassCubit>(() => ResetPassCubit(getIt()));

  getIt.registerLazySingleton<ProfileRepo>(() => ProfileRepoImp(getIt()));
  getIt.registerLazySingleton<ProfileCubit>(() => ProfileCubit(getIt()));
}

/// Drops the per-user cubits so the next user never sees the previous
/// user's data.
void resetUserCubits() {
  getIt.resetLazySingleton<ProfileCubit>();
  getIt.resetLazySingleton<CalendarCubit>();
}
